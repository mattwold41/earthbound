package com.earthbound;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;

/**
 * Cached road mask for the Guemes Island test region.
 * Source: U.S. Census Bureau TIGERweb Transportation_LargeScale.
 */
public final class EarthRoadData {

    private static final double GUEMES_WEST = -122.70;
    private static final double GUEMES_SOUTH = 48.47;
    private static final double GUEMES_EAST = -122.55;
    private static final double GUEMES_NORTH = 48.60;

    // Higher than the elevation test raster so narrow roads survive rasterization.
    private static final int MASK_WIDTH = 2048;
    private static final int MASK_HEIGHT = 2048;

    private static final String ROAD_SERVICE =
            "https://tigerweb.geo.census.gov/arcgis/rest/services/"
                    + "TIGERweb/Transportation_LargeScale/MapServer";

    private static volatile boolean[][] roadMask;

    private EarthRoadData() {
    }

    public static boolean loadGuemesRoadMask() {
        HttpURLConnection connection = null;

        try {
            System.out.println("[EarthBound] Downloading Guemes road mask...");

            String address = ROAD_SERVICE
                    + "/export"
                    + "?bbox=" + GUEMES_WEST + "," + GUEMES_SOUTH + ","
                    + GUEMES_EAST + "," + GUEMES_NORTH
                    + "&bboxSR=4326"
                    + "&imageSR=4326"
                    + "&size=" + MASK_WIDTH + "," + MASK_HEIGHT
                    // LargeScale: 0 primary, 1 secondary, 2 local roads.
                    + "&layers=show:0,1,2"
                    + "&transparent=true"
                    + "&format=png32"
                    + "&f=image";

            URL url = URI.create(address).toURL();
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(15000);
            connection.setReadTimeout(30000);

            int responseCode = connection.getResponseCode();
            if (responseCode != 200) {
                System.out.println("[EarthBound] Road mask request failed. HTTP " + responseCode);
                return false;
            }

            BufferedImage image;
            try (InputStream input = connection.getInputStream()) {
                image = ImageIO.read(input);
            }

            if (image == null) {
                System.out.println("[EarthBound] Road mask PNG could not be decoded.");
                return false;
            }

            int width = image.getWidth();
            int height = image.getHeight();
            boolean[][] newMask = new boolean[height][width];
            int roadCells = 0;

            for (int y = 0; y < height; y++) {
                for (int x = 0; x < width; x++) {
                    int alpha = (image.getRGB(x, y) >>> 24) & 0xFF;
                    boolean road = alpha > 20;
                    newMask[y][x] = road;
                    if (road) {
                        roadCells++;
                    }
                }
            }

            roadMask = newMask;
            System.out.println("[EarthBound] Guemes road mask loaded: "
                    + width + " x " + height + ", road pixels=" + roadCells);
            return true;

        } catch (Exception exception) {
            System.out.println("[EarthBound] Failed to load Guemes road mask.");
            exception.printStackTrace();
            return false;

        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
    }

    public static boolean isLoaded() {
        return roadMask != null;
    }

    public static boolean isRoad(double latitude, double longitude) {
        boolean[][] mask = roadMask;
        if (mask == null) {
            return false;
        }

        if (latitude < GUEMES_SOUTH || latitude > GUEMES_NORTH
                || longitude < GUEMES_WEST || longitude > GUEMES_EAST) {
            return false;
        }

        double xPercent = (longitude - GUEMES_WEST) / (GUEMES_EAST - GUEMES_WEST);
        double yPercent = (GUEMES_NORTH - latitude) / (GUEMES_NORTH - GUEMES_SOUTH);

        int width = mask[0].length;
        int height = mask.length;
        int x = clamp((int) Math.round(xPercent * (width - 1)), 0, width - 1);
        int y = clamp((int) Math.round(yPercent * (height - 1)), 0, height - 1);

        // A tiny dilation makes thin source lines into usable Minecraft roads.
        for (int dy = -1; dy <= 1; dy++) {
            for (int dx = -1; dx <= 1; dx++) {
                int px = x + dx;
                int py = y + dy;
                if (px >= 0 && px < width && py >= 0 && py < height && mask[py][px]) {
                    return true;
                }
            }
        }

        return false;
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }
}
