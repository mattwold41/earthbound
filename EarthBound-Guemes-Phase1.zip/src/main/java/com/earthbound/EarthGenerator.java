package com.earthbound;

import org.bukkit.Material;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.generator.WorldInfo;

import java.util.Random;

public class EarthGenerator extends ChunkGenerator {

    private static final int SEA_LEVEL = EarthWaterData.SEA_LEVEL;
    private static final int OCEAN_FLOOR = SEA_LEVEL - 5;

    @Override
    public void generateNoise(
            WorldInfo worldInfo,
            Random random,
            int chunkX,
            int chunkZ,
            ChunkData chunkData) {

        for (int x = 0; x < 16; x++) {
            for (int z = 0; z < 16; z++) {

                int worldX = chunkX * 16 + x;
                int worldZ = chunkZ * 16 + z;

                double latitude = EarthCoordinates.getLatitude(worldX, worldZ);
                double longitude = EarthCoordinates.getLongitude(worldX, worldZ);

                boolean water = EarthWaterData.isWater(latitude, longitude);
                boolean road = !water && EarthRoadData.isRoad(latitude, longitude);

                Double elevation = EarthTerrainLoader.getGuemesElevation(latitude, longitude);

                int terrainHeight;
                if (water) {
                    // USGS land elevation is not bathymetry, so use a safe test seabed.
                    terrainHeight = OCEAN_FLOOR;
                } else if (elevation != null && Double.isFinite(elevation)) {
                    terrainHeight = EarthElevation.getMinecraftHeight(elevation);
                } else {
                    terrainHeight = SEA_LEVEL;
                }

                terrainHeight = Math.max(
                        worldInfo.getMinHeight(),
                        Math.min(worldInfo.getMaxHeight() - 1, terrainHeight)
                );

                for (int y = worldInfo.getMinHeight(); y <= terrainHeight; y++) {
                    Material material;

                    if (y == terrainHeight) {
                        if (water) {
                            material = Material.SAND;
                        } else if (road) {
                            material = Material.GRAY_CONCRETE;
                        } else {
                            material = Material.GRASS_BLOCK;
                        }
                    } else if (y >= terrainHeight - 3) {
                        material = water ? Material.SAND : Material.DIRT;
                    } else {
                        material = Material.STONE;
                    }

                    chunkData.setBlock(x, y, z, material);
                }

                if (water) {
                    int waterTop = Math.min(SEA_LEVEL, worldInfo.getMaxHeight() - 1);
                    for (int y = terrainHeight + 1; y <= waterTop; y++) {
                        chunkData.setBlock(x, y, z, Material.WATER);
                    }
                }
            }
        }
    }
}
