# EarthBound

EarthBound is a Paper plugin prototype for a real-Earth Minecraft world.

## Guemes Island Phase 1

This build includes:
- USGS 3DEP elevation raster loading.
- U.S. Census Bureau TIGERweb areal-hydrography water mask.
- U.S. Census Bureau TIGERweb primary, secondary, and local road mask.
- Minecraft terrain, ocean water, and road surface generation from those cached datasets.
- `/earth locate` coordinate/elevation command.

The current test bounds are the Guemes Island / nearby Anacortes area. Horizontal scale is 1 Minecraft block = 2 real meters.

## Data credits

- Elevation data: U.S. Geological Survey (USGS), National Geospatial Program, 3DEP.
- Hydrography and roads: U.S. Census Bureau TIGERweb.

This is an early geographic prototype. Road rendering uses a cached raster mask and ocean depth is currently a test depth, not bathymetry.
